 
   {productquantity}
  
  <div class="col-sm-6 col-md-4">
    <div class="thumbnail">
      <img src="..." alt="...">
      <div class="caption">
        
        <h3>{image}</h3>
        <p>{name}
        {price}</p>$
        <p><a href="ChopingCart/Buy/{$id}" class="btn btn-primary" role="button">Order Now</a> </p>
      </div>
    </div>
  </div>

    {/productquantity}  