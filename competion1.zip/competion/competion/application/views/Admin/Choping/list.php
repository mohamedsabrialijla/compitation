
<?php 
  
   $u=new Product_Quantity();
   $u->index();
		 
   $u=new P_Download();
   $u->index();
	 ?>	 		 
		 		 
		
	