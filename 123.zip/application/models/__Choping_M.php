<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
include("MyModel.php");
class ‏‏Choping_M extends MyModel {
	function __construct(){
		parent ::__construct();
		$this->tableName = "‏‏choping";
	    }
		
		
	 
	 
	}
	
?>	   